# Module 01: System thinking

## Nội dung báo cáo:

[Định lý CAP, khái niệm eventual consistency](Cap_theorem.md)

[Khái niệm throughput, latency](Latency-throughput.md)

[Các phương pháp để scale database (MySQL)](Scale_database.md)

[Task Queue khác gì Message Queue?](TaskQueue_MessageQueue.md)

## Bài tập

[Load balancer](Load_balancer.md)

[Caching](Caching.md)

[Redis](Redis.md)