# Latency vs Throughput

## Latency
- Là thời gian cần thiết để thực hiện một số hành động (actions) hoặc để tạo ra một số kết quả(result).
- Được đo theo đơn vị thời gian: Giờ, phút, giây, nano giây,...

## Throughput
 
- Là số  hành động được thực hiện hoặc kết quả được tạo ra trên một đơn vị thời gian

## Example
Một nhà máy sản xuất xe hơi có dây chuyền sản xuất như sau:
Phải mất 8 giờ để sản xuất một chiếc xe và nhà máy sản xuất 120 chiếc xe mỗi ngày

Khi đó:

latency: 8 giờ

throughput: 120 xe / ngày 
