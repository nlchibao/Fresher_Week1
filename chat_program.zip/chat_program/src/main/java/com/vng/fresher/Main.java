package com.vng.fresher;


public class Main {
    public static void main(String[] args) {
        new Chat().Run();

    }
}
